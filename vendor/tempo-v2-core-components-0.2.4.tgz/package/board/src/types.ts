import type { CSSProperties, KeyboardEventHandler, PointerEventHandler } from "react";

export type BoardColor = "white" | "black";
export type Square = `${"a" | "b" | "c" | "d" | "e" | "f" | "g" | "h"}${1 | 2 | 3 | 4 | 5 | 6 | 7 | 8}`;
export type BoardMode = "legal" | "free" | "select";
export type BoardTheme = "brown" | "blue" | "green";
export type PieceSet = "cburnett" | "merida";
export type PieceRole = "pawn" | "knight" | "bishop" | "rook" | "queen" | "king";

export interface PositionIdentity {
  readonly positionIdentity: string;
  readonly positionRevision: number;
}

/** Plain display data. No executable SVG, application stores, or legality rules. */
export interface BoardShape {
  readonly orig: Square;
  readonly dest?: Square;
  readonly brush?: "green" | "red" | "blue" | "yellow" | "maia";
  readonly modifiers?: { readonly lineWidth?: number; readonly hilite?: string };
  readonly piece?: { readonly role: PieceRole; readonly color: BoardColor; readonly scale?: number };
  readonly label?: { readonly text: string; readonly fill?: string };
  readonly below?: boolean;
}

export interface MoveEvent extends PositionIdentity {
  readonly from: Square;
  readonly to: Square;
}
export interface SelectEvent extends PositionIdentity { readonly square: Square }
export interface DrawingEvent extends PositionIdentity { readonly shapes: readonly BoardShape[] }
export interface InteractionEvent extends PositionIdentity { readonly type: "focus" | "blur" }

/** Detached, read-only diagnostics. No renderer or DOM nodes cross this seam. */
export interface BoardInputSnapshot {
  readonly started: boolean;
  readonly origin: Square;
  readonly originalPointer: readonly [number, number];
  readonly orientation: BoardColor;
  readonly bounds: { readonly left: number; readonly top: number; readonly width: number; readonly height: number };
  readonly animation: { readonly enabled: boolean; readonly durationMs: number };
  readonly piecePosition: readonly [number, number] | null;
}
export interface BoardDiagnosticEvent extends PositionIdentity {
  readonly kind: "cancel-move" | "set" | "annotations" | "redraw";
  readonly changed: readonly string[];
}

export interface BoardProps extends PositionIdentity {
  readonly fen: string;
  readonly orientation: BoardColor;
  readonly turn: BoardColor;
  readonly check: BoardColor | false;
  readonly mode: BoardMode;
  readonly locked?: boolean;
  /** Keep the renderer's submitted move while locked on the same position. */
  readonly retainMoveOnLock?: boolean;
  readonly readOnly?: boolean;
  /** Supplied by the caller. Equivalent maps do not invalidate held input. */
  readonly destinations?: ReadonlyMap<Square, readonly Square[]>;
  readonly showDestinations?: boolean;
  readonly drawingEnabled?: boolean;
  /** Permit drawing while piece movement is locked or read-only. */
  readonly drawingWhileLocked?: boolean;
  readonly theme?: BoardTheme;
  readonly pieceSet?: PieceSet;
  readonly coordinates?: "squares" | "edges";
  readonly lastMove?: readonly [Square, Square];
  readonly shapes?: readonly BoardShape[];
  readonly drawnShapes?: readonly BoardShape[];
  readonly maxSize?: number;
  /** Opt in for a main desktop board. The chosen size lives in this mount. */
  readonly resizeMode?: "desktop";
  /** Pointer input on the chess surface, independent of the resize handle. */
  readonly onSurfacePointerDown?: PointerEventHandler<HTMLDivElement>;
  /** Optional heading/palette whose resize can translate the board. */
  readonly layoutAnchor?: HTMLElement | null;
  readonly ariaLabel?: string;
  readonly ariaDescribedBy?: string;
  readonly tabIndex?: number;
  readonly className?: string;
  readonly style?: CSSProperties;
  /** Application keyboard bindings stay with the caller. */
  readonly onKeyDown?: KeyboardEventHandler<HTMLDivElement>;
  readonly onMove?: (event: MoveEvent) => void;
  /** A move attempt to an on-board square outside the supplied legal destinations. */
  readonly onRejectedMove?: (event: MoveEvent) => void;
  readonly onFreeMove?: (event: MoveEvent) => void;
  readonly onSelect?: (event: SelectEvent) => void;
  readonly onDrawingChange?: (event: DrawingEvent) => void;
  readonly onInteraction?: (event: InteractionEvent) => void;
  /** Opt-in caller diagnostics; package rendering installs no telemetry. */
  readonly onDiagnosticEvent?: (event: BoardDiagnosticEvent) => void;
}

export interface BoardHandle {
  focus(): void;
  /** Current held input as detached values, or null when idle/disposed. */
  readInputSnapshot(): BoardInputSnapshot | null;
  /** Cancel pending input, fence deferred events, and restore the supplied FEN. */
  clearInput(): void;
  /** Preview the chosen promotion on the pawn already moved to this square. */
  previewPromotion(square: Square, role: Exclude<PieceRole, "pawn" | "king">): void;
  /** Refresh hit testing without replacing pieces or interrupting a drag. */
  clearInputBounds(): void;
  /** Keyboard seam; follows the same mode, lock, and supplied destinations. */
  selectSquare(square: Square | null): void;
}
